<?php
defined('IN_DESTOON') or exit('Access Denied');
/*
	[Destoon B2B System] Copyright (c) 2008-2016 Destoon.COM
	This is NOT a freeware, use is subject to license.txt
*/
$CFG['database'] = 'mysql';
$CFG['pconnect'] = '0';
$CFG['db_host'] = 'localhost';
$CFG['db_name'] = 'teseguan';
$CFG['db_user'] = 'root';
$CFG['db_pass'] = 'root';
$CFG['db_charset'] = 'utf8';
$CFG['db_expires'] = '0';
$CFG['tb_pre'] = 'ts_';
$CFG['charset'] = 'utf-8';
$CFG['url'] = 'http://192.168.100.146/';
$CFG['com_domain'] = '';
$CFG['com_dir'] = '1';
$CFG['com_rewrite'] = '0';
$CFG['com_vip'] = 'VIP';
$CFG['file_mod'] = 0777;
$CFG['cache'] = 'file';
$CFG['cache_pre'] = 'c0m_';
$CFG['cache_dir'] = '';
$CFG['tag_expires'] = '0';
$CFG['template_refresh'] = '1';
$CFG['cookie_domain'] = '';
$CFG['cookie_path'] = '/';
$CFG['cookie_pre'] = 'cf6_';
$CFG['session'] = 'file';
$CFG['editor'] = 'fckeditor';
$CFG['timezone'] = 'Etc/GMT-8';
$CFG['timediff'] = '0';
$CFG['skin'] = 'default';
$CFG['template'] = 'teseguan';
$CFG['language'] = 'zh-cn';
$CFG['authadmin'] = 'session';
$CFG['authkey'] = 'jFFBQ6vGn1W9GKIP';
$CFG['static'] = '';
$CFG['cloud_uid'] = '41897';
$CFG['cloud_key'] = 'htchnblvxwbmccju';
$CFG['edittpl'] = '1';
$CFG['executesql'] = '0';
$CFG['founderid'] = '1';
?>